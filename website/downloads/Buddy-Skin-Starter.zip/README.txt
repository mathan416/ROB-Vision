BUDDY SKIN STARTER

Open R.O.B.-Vision-Buddy-Skin-Artist-Guide.pdf first.
Import this ZIP in Setup > Skins to see the sample head.
assets/head.svg is the head artwork currently selected in skin.json.
The other files in assets/ are editable examples for every allowed part.
They do not appear in Buddy until you add their filenames to skin.json,
or upload the parts through Setup. Unlisted examples are not saved on import.
Replace assets/head.svg with your art, or use Setup to upload individual parts.
Omit any entry in skin.json to keep that original Buddy part.
Only Buddy and fixed stage fixtures can change. Gyros and Stack-Up blocks always keep their original artwork.
The reference folder is for drawing guides and is ignored by the app.
See reference/layer-order.txt to plan which parts sit in front.
